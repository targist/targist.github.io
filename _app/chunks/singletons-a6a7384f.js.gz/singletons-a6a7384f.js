let t;function e(r){t=r.router}export{e as i,t as r};
