import{S as e,i as t,s as a}from"../../../chunks/vendor-0fbb5e6e.js";class o extends e{constructor(s){super();t(this,s,null,null,a,{})}}export{o as default};
