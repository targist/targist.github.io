import{S as _,i as m,s as f,e as p,t as y,F as v,c as g,a as h,d as i,h as L,G as j,b as G,H as l,I as u,J as P,w as T,k as q,x as H,m as M,y as S,g as b,K as k,L as C,M as E,q as $,o as w,B as I}from"../chunks/vendor-9dc9bc73.js";/* empty css                    */function x(r){let e,o,s,n;return{c(){e=p("script"),s=p("script"),n=y(`window.dataLayer = window.dataLayer || [];
		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'G-5PT8M92H35');`),this.h()},l(a){const t=v('[data-svelte="svelte-ude3sm"]',document.head);e=g(t,"SCRIPT",{src:!0});var c=h(e);c.forEach(i),s=g(t,"SCRIPT",{});var d=h(s);n=L(d,`window.dataLayer = window.dataLayer || [];
		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'G-5PT8M92H35');`),d.forEach(i),t.forEach(i),this.h()},h(){e.async=!0,j(e.src,o="https://www.googletagmanager.com/gtag/js?id=G-5PT8M92H35")||G(e,"src",o)},m(a,t){l(document.head,e),l(document.head,s),l(s,n)},p:u,i:u,o:u,d(a){i(e),i(s)}}}class D extends _{constructor(e){super();m(this,e,null,x,f,{})}}function R(r){let e,o,s;e=new D({});const n=r[1].default,a=P(n,r,r[0],null);return{c(){T(e.$$.fragment),o=q(),a&&a.c()},l(t){H(e.$$.fragment,t),o=M(t),a&&a.l(t)},m(t,c){S(e,t,c),b(t,o,c),a&&a.m(t,c),s=!0},p(t,[c]){a&&a.p&&(!s||c&1)&&k(a,n,t,t[0],s?E(n,t[0],c,null):C(t[0]),null)},i(t){s||($(e.$$.fragment,t),$(a,t),s=!0)},o(t){w(e.$$.fragment,t),w(a,t),s=!1},d(t){I(e,t),t&&i(o),a&&a.d(t)}}}function A(r,e,o){let{$$slots:s={},$$scope:n}=e;return r.$$set=a=>{"$$scope"in a&&o(0,n=a.$$scope)},[n,s]}class J extends _{constructor(e){super();m(this,e,A,R,f,{})}}export{J as default};
