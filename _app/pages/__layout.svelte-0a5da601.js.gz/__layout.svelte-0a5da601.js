import{S as _,i as m,s as f,e as g,t as y,F as v,c as p,a as h,d as i,h as L,G as j,b as G,H as l,I as u,J as M,w as P,k as S,x as T,m as q,y as C,g as H,K as k,L as A,M as E,q as $,o as w,B as I,v as b}from"../chunks/vendor-9835d907.js";import{c as x}from"../chunks/AuthService-8c76074c.js";function D(r){let e,o,s,n;return{c(){e=g("script"),s=g("script"),n=y(`window.dataLayer = window.dataLayer || [];
		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'G-5PT8M92H35');`),this.h()},l(a){const t=v('[data-svelte="svelte-ude3sm"]',document.head);e=p(t,"SCRIPT",{src:!0});var c=h(e);c.forEach(i),s=p(t,"SCRIPT",{});var d=h(s);n=L(d,`window.dataLayer = window.dataLayer || [];
		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'G-5PT8M92H35');`),d.forEach(i),t.forEach(i),this.h()},h(){e.async=!0,j(e.src,o="https://www.googletagmanager.com/gtag/js?id=G-5PT8M92H35")||G(e,"src",o)},m(a,t){l(document.head,e),l(document.head,s),l(s,n)},p:u,i:u,o:u,d(a){i(e),i(s)}}}class R extends _{constructor(e){super();m(this,e,null,D,f,{})}}function B(r){let e,o,s;e=new R({});const n=r[1].default,a=M(n,r,r[0],null);return{c(){P(e.$$.fragment),o=S(),a&&a.c()},l(t){T(e.$$.fragment,t),o=q(t),a&&a.l(t)},m(t,c){C(e,t,c),H(t,o,c),a&&a.m(t,c),s=!0},p(t,[c]){a&&a.p&&(!s||c&1)&&k(a,n,t,t[0],s?E(n,t[0],c,null):A(t[0]),null)},i(t){s||($(e.$$.fragment,t),$(a,t),s=!0)},o(t){w(e.$$.fragment,t),w(a,t),s=!1},d(t){I(e,t),t&&i(o),a&&a.d(t)}}}function F(r,e,o){let{$$slots:s={},$$scope:n}=e;return b(()=>{x()}),r.$$set=a=>{"$$scope"in a&&o(0,n=a.$$scope)},[n,s]}class z extends _{constructor(e){super();m(this,e,F,B,f,{})}}export{z as default};
