import{S as h,i as $,s as w,e as _,t as y,F as v,c as m,a as f,d as i,h as L,G,b as M,H as l,I as u,J as P,w as T,k as q,x as C,m as H,y as S,g as j,K as E,L as I,M as b,q as g,o as p,B as x,v as A}from"../chunks/vendor-f171eead.js";import{c as D}from"../chunks/AuthService-36a747e8.js";function R(r){let e,o,s,n;return{c(){e=_("script"),s=_("script"),n=y(`window.dataLayer = window.dataLayer || [];
		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'G-5PT8M92H35');`),this.h()},l(a){const t=v('[data-svelte="svelte-ude3sm"]',document.head);e=m(t,"SCRIPT",{src:!0});var c=f(e);c.forEach(i),s=m(t,"SCRIPT",{});var d=f(s);n=L(d,`window.dataLayer = window.dataLayer || [];
		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'G-5PT8M92H35');`),d.forEach(i),t.forEach(i),this.h()},h(){e.async=!0,G(e.src,o="https://www.googletagmanager.com/gtag/js?id=G-5PT8M92H35")||M(e,"src",o)},m(a,t){l(document.head,e),l(document.head,s),l(s,n)},p:u,i:u,o:u,d(a){i(e),i(s)}}}class k extends h{constructor(e){super();$(this,e,null,R,w,{})}}function B(r){let e,o,s;e=new k({});const n=r[1].default,a=P(n,r,r[0],null);return{c(){T(e.$$.fragment),o=q(),a&&a.c()},l(t){C(e.$$.fragment,t),o=H(t),a&&a.l(t)},m(t,c){S(e,t,c),j(t,o,c),a&&a.m(t,c),s=!0},p(t,[c]){a&&a.p&&(!s||c&1)&&E(a,n,t,t[0],s?b(n,t[0],c,null):I(t[0]),null)},i(t){s||(g(e.$$.fragment,t),g(a,t),s=!0)},o(t){p(e.$$.fragment,t),p(a,t),s=!1},d(t){x(e,t),t&&i(o),a&&a.d(t)}}}function F(r,e,o){let{$$slots:s={},$$scope:n}=e;return A(()=>{D()}),r.$$set=a=>{"$$scope"in a&&o(0,n=a.$$scope)},[n,s]}class z extends h{constructor(e){super();$(this,e,F,B,w,{})}}export{z as default};
