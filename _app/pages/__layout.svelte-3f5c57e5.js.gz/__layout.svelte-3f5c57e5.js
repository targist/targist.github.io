import{S as h,i as $,s as w,e as m,t as y,F as v,c as _,a as f,d as c,h as L,G,b as M,H as l,I as u,J as P,w as T,k as q,x as C,m as H,y as S,g as j,K as D,L as E,M as I,q as g,o as p,B as b,v as x}from"../chunks/vendor-31a8d0de.js";import{i as R}from"../chunks/AuthService-1268c3b6.js";import"../chunks/preload-helper-ec9aa979.js";function k(r){let a,o,s,n;return{c(){a=m("script"),s=m("script"),n=y(`window.dataLayer = window.dataLayer || [];
		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'G-5PT8M92H35');`),this.h()},l(e){const t=v('[data-svelte="svelte-ude3sm"]',document.head);a=_(t,"SCRIPT",{src:!0});var i=f(a);i.forEach(c),s=_(t,"SCRIPT",{});var d=f(s);n=L(d,`window.dataLayer = window.dataLayer || [];
		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'G-5PT8M92H35');`),d.forEach(c),t.forEach(c),this.h()},h(){a.async=!0,G(a.src,o="https://www.googletagmanager.com/gtag/js?id=G-5PT8M92H35")||M(a,"src",o)},m(e,t){l(document.head,a),l(document.head,s),l(s,n)},p:u,i:u,o:u,d(e){c(a),c(s)}}}class A extends h{constructor(a){super();$(this,a,null,k,w,{})}}function B(r){let a,o,s;a=new A({});const n=r[1].default,e=P(n,r,r[0],null);return{c(){T(a.$$.fragment),o=q(),e&&e.c()},l(t){C(a.$$.fragment,t),o=H(t),e&&e.l(t)},m(t,i){S(a,t,i),j(t,o,i),e&&e.m(t,i),s=!0},p(t,[i]){e&&e.p&&(!s||i&1)&&D(e,n,t,t[0],s?I(n,t[0],i,null):E(t[0]),null)},i(t){s||(g(a.$$.fragment,t),g(e,t),s=!0)},o(t){p(a.$$.fragment,t),p(e,t),s=!1},d(t){b(a,t),t&&c(o),e&&e.d(t)}}}function F(r,a,o){let{$$slots:s={},$$scope:n}=a;return x(async()=>{await R()}),r.$$set=e=>{"$$scope"in e&&o(0,n=e.$$scope)},[n,s]}class N extends h{constructor(a){super();$(this,a,F,B,w,{})}}export{N as default};
