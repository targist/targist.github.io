import{S as h,i as $,s as w,e as _,t as y,F as L,c as m,a as f,d as i,h as v,G,b as P,H as l,E as u,I as T,w as q,k as E,x as H,m as S,y as j,g as C,J as I,K as M,L as b,q as g,o as p,B as x}from"../chunks/index-f40bfaf5.js";/* empty css                    */function D(r){let e,o,s,n;return{c(){e=_("script"),s=_("script"),n=y(`window.dataLayer = window.dataLayer || [];
		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'G-5PT8M92H35');`),this.h()},l(a){const t=L('[data-svelte="svelte-ude3sm"]',document.head);e=m(t,"SCRIPT",{src:!0});var c=f(e);c.forEach(i),s=m(t,"SCRIPT",{});var d=f(s);n=v(d,`window.dataLayer = window.dataLayer || [];
		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'G-5PT8M92H35');`),d.forEach(i),t.forEach(i),this.h()},h(){e.async=!0,G(e.src,o="https://www.googletagmanager.com/gtag/js?id=G-5PT8M92H35")||P(e,"src",o)},m(a,t){l(document.head,e),l(document.head,s),l(s,n)},p:u,i:u,o:u,d(a){i(e),i(s)}}}class R extends h{constructor(e){super();$(this,e,null,D,w,{})}}function k(r){let e,o,s;e=new R({});const n=r[1].default,a=T(n,r,r[0],null);return{c(){q(e.$$.fragment),o=E(),a&&a.c()},l(t){H(e.$$.fragment,t),o=S(t),a&&a.l(t)},m(t,c){j(e,t,c),C(t,o,c),a&&a.m(t,c),s=!0},p(t,[c]){a&&a.p&&(!s||c&1)&&I(a,n,t,t[0],s?b(n,t[0],c,null):M(t[0]),null)},i(t){s||(g(e.$$.fragment,t),g(a,t),s=!0)},o(t){p(e.$$.fragment,t),p(a,t),s=!1},d(t){x(e,t),t&&i(o),a&&a.d(t)}}}function A(r,e,o){let{$$slots:s={},$$scope:n}=e;return r.$$set=a=>{"$$scope"in a&&o(0,n=a.$$scope)},[n,s]}class J extends h{constructor(e){super();$(this,e,A,k,w,{})}}export{J as default};
